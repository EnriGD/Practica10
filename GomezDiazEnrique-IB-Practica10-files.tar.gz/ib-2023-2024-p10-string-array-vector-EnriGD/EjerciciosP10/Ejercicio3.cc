#include <iostream>
#include "Ejercicio1.h"

int main(){
    int tamanio;
    double menor, mayor, maximo, minimo, promedio;
    std::cin >> tamanio >> menor >> mayor;
    std::vector<double> vector = GenerateVector(tamanio, menor, mayor);
    MostrarVector(vector);
    valores_vector(vector, minimo, maximo, promedio);
    std::cout << minimo << " " << maximo << " " << promedio << std::endl;

    return 0;
}