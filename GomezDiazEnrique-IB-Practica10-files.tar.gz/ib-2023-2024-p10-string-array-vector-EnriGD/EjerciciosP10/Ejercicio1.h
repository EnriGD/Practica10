#include <iostream>
#include <vector>


std::vector<double> GenerateVector(const int size, const double lower, const double upper){
    std::vector<double> my_vector;
    int minimo = (lower * 100);
    int maximo = (upper * 100);
    for(int i = 0; i < size; i++){
        double variable = minimo + std::rand() % maximo;
        variable /= 100.0;
        my_vector.push_back(variable);

    }

    return my_vector;
}

void MostrarVector(std::vector<double> my_vector){
    for(int i = 0; i < my_vector.size(); i++){
        std::cout << my_vector[i] << " ";
    }
    std::cout << std::endl;

}

double ReducedSum(std::vector<double> my_vector){
    double resultado = 0.0;
    for(int i = 0; i < my_vector.size(); i++){
        resultado += my_vector[i];
    }

    return resultado;
}

void valores_vector(std::vector<double> my_vector, double &minimo, double &maximo, double &promedio){
    minimo = my_vector[0];
    maximo = my_vector[0];
    promedio = 0.0;
    for(int i = 0; i < my_vector.size(); i++){
        if(minimo > my_vector[i]) {
            minimo = my_vector[i];
        }
        if(maximo < my_vector[i]){
            maximo = my_vector[i];
        }
        promedio += my_vector[i];
    }
    promedio /= my_vector.size();
}

std::vector<double> SumaDeVectores(std::vector<double> vector1, std::vector<double> vector2){
    std::vector<double> my_vector;
    for(int i = 0; i < vector1.size(); i++){
        my_vector.push_back(vector1[i]);
    }
    for(int j = 0; j < vector2.size(); j++){
        my_vector.push_back(vector2[j]);
    }

    return my_vector;
}