#include <iostream>
#include "Ejercicio1.h"

int main(){
    int tamanio;
    double menor, mayor;
    std::cin >> tamanio >> menor >> mayor;
    std::vector<double> vectorPrincipal = GenerateVector(tamanio, menor, mayor);
    MostrarVector(vectorPrincipal);
    std::cout << ReducedSum(vectorPrincipal) << std::endl;

    return 0;
}