#include <iostream>
#include <vector>
#include <random>

std::vector<double> GenerateVector(const int size, const double lower, const double upper){
    std::vector<double> my_vector;
    int minimo = lower * 100;
    int maximo = upper * 100;
    for(int i = 0; i < size; i++){
        double variable = (minimo + std::rand() % maximo) / 100.0;
        my_vector.push_back(variable);

    }

    return my_vector;
}

int main(){
    int tamanio;
    double lower, upper;
    std::vector<double> vectorfinal;
    //std::cin >> tamanio >> lower >> upper;
    tamanio = 3;
    lower = 3.0;
    upper = 7.0;
    std::vector<double> vectorFinal = GenerateVector(tamanio, lower, upper);
    for(int i = 0; i < vectorFinal.size(); i++){
        std::cout << vectorFinal[i] << " ";
    }
    std::cout << std::endl;


    return 0;
}