 /**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Enrique Gómez Díaz
 * @date 22 noviembre
 * @brief pasar una cadena de caracteres en string, y almacenar cada caracter en un array char
 *
 */

#include <iostream>
#include <string>
#include <array>

/**
* @brief funcion que guarda en un arry de caracteres los caracteres de un string (con máximo de 7)
* @param cadena de caracteres string
* @return array con los caracteres de la cadena
*/
std::array<char, 7> StringToArray(const std::string& cadena){
    std::array<char, 7> resultado;
    int aux;
    for(int i = 0; i < 7; i++){
        aux = i;
        if(i > cadena.size() - 1){
            aux %= cadena.size();
        }
        resultado[i] = cadena[aux];
    }

    return resultado;
} 

int main(){
    std::string cadena;
    std::cin >> cadena;
    std::array<char, 7> resultado = StringToArray(cadena);

    for(int j = 0; j < 7; j++){
        std::cout << resultado[j] << " ";
    }

    std::cout << std::endl;

    return 0;
}
